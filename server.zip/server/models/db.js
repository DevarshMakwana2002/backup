const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    Profile : String,
    Fname: String,
    Lname : String,
    Age : String,
    Email : String,
})

const Model = mongoose.model("employee",schema)

module.exports = Model