const express = require("express");
const employee = require("../controller/employee");

const router = express.Router();

router.route("/api/all").get(employee.employeeGet);

router.route("/api/addEmployee").post(employee.employeePost);

module.exports = router;
