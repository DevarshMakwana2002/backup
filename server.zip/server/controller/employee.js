const Model = require("../models/db");

const employeeGet = async (req, res) => {
    console.log("hit to get controller")
    console.log(req.query)
    const page = req.query.page * 1 || 1
    const limit = req.query.limit * 1 || 10
    const skip = (page - 1) * limit
    const data = await Model.find().limit(limit).skip(skip)
    const total = await Model.count()
    
    // res.send({
    //     data,total
    // })

    res.status(200).json({
        data,total
    })
    // res.end()
};

const employeePost = async (req, res) => {
    console.log("hit to post controller");
    // console.log(req.body);
    ///////////////////////////////////////////////////////
    const data = new Model(req.body);
    if(!(req.body.length === 0)) {
        data.save().then(() => {
            console.log("saved");
        });
    }
    //////////////////////////////////////////////
    res.end();
};

module.exports = { employeeGet, employeePost };
