const express = require('express');
const router = require('./routes/employee')
var cors = require('cors')

const app = express();

// app.use(cors({
    //     origin:"http://localhost:3001"
    // }));
    app.use(cors())
    app.use(express.json())
app.use(express.static(`${__dirname} + '/public`));

// app.use('Access-Control-Allow-Origin')

app.use(router)

module.exports = app