const app = require('./app');
const mongoose = require('mongoose')
const uri = 'mongodb://localhost:27017/employees'

mongoose.connect(uri).then(()=>{
    console.log("connected to mongo")
}).catch(err => {
    console.log("error connecting to mongo\n"+err)
})

app.listen(5002,()=>{
    console.log("listening on port "+5002)
})