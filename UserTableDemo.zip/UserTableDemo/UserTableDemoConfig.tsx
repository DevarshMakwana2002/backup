import React from 'react';

const UserTableDemoConfig:{} = {
	settings: {
		layout: {
			config: {
				navbar: {
					display: true
				},
				toolbar: {
					display: true
				},
				footer: {
					display: true
				},
				leftSidePanel: {
					display: true
				},
				rightSidePanel: {
					display: true
				}
			}
		}
	},
	routes: [
		{
			path: '/:url_key?/userTable',
			component: React.lazy(() => import('./UserTableDemo'))
		}
	]
};

export default UserTableDemoConfig;	
