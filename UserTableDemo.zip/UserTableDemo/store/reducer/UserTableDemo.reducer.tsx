import * as Actions from "../actions/UserTableDemo.actions";
// import _ from "@lodash";

const initialState = {
  users: [],
  userCount: 0,
};

const UserTableDemoReducer = (state = initialState, action) => {
  switch (action.type) {
    case Actions.GET_ALL_USERS:
      return {
        ...state,
        users: [...action.payload.data],
        count: action.payload.dataCount,
      };
      break;

    case Actions.DELETE_USER:
      return {
        ...state,
        users: action.payload.data,
        count: action.payload.dataCount,
      };

    case Actions.ADD_USER:
      return {
        ...state,
        users: action.payload.data,
        count: action.payload.dataCount,
      };

    case Actions.UPDATE_USER:
      return {
        ...state,
        users: action.payload.data,
        count: action.payload.dataCount,
      };

    case Actions.SOFT_DELETE_USER:
      return {
        ...state,
        users: action.payload.data,
        count: action.payload.dataCount,
      };

    default:
      return state;
  }
};

export default UserTableDemoReducer;
