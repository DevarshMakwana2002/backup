import { axiosInstance } from "../../../../services/axios/axiosConfig";
import { showMessage } from "../../../../store/actions";

export const GET_ALL_USERS = "GET_ALL_USERS";
export const DELETE_USER = "DELETE_USER";
export const ADD_USER = "ADD_USER";
export const UPDATE_USER = "UPDATE_USER";
export const SOFT_DELETE_USER = "SOFT_DELETE_USER";

let limitGloble = 5;
let pageGloble = 0;
let isActiveGloble = 1;

export const getUserData = (limit, page, isActive) => {
  return async (dispatch) => {
    try {
      limitGloble = limit;
      pageGloble = page;
      isActiveGloble = isActive;

      const { data } = await axiosInstance({
        method: "get",
        url: `http://localhost:5007/get_all/?limit=${limit}&page=${page}&isActive=${isActive}`,
      });
      dispatch({ type: GET_ALL_USERS, payload: data });
      return data;
    } catch (error) {
      dispatch(
        showMessage({
          message: "faild to get user data",
          variant: "error",
        })
      );
      return false;
    }
  };
};

export const deleteUserData = (id) => {
  return async (dispatch) => {
    try {
      const response = await axiosInstance({
        method: "delete",
        url: `http://localhost:5007/delete_forever`,
        data: { id },
      });
      if (!response) {
        throw new Error("Delete failed");
      } else {
        dispatch(
          showMessage({
            message: "Deleted successfully",
            variant: "success",
          })
        );
        const data = getUserData(limitGloble, pageGloble, isActiveGloble);
        dispatch({ type: DELETE_USER, payload: data });
        return data;
      }
    } catch (error) {
      dispatch(
        showMessage({
          message: "faild to delete user data",
          variant: "error",
        })
      );
      return false;
    }
  };
};

export const addUserData = (dataObj) => {
  return async (dispatch) => {
    try {
      const response = await axiosInstance({
        method: "post",
        url: `http://localhost:5007/post`,
        data: dataObj,
      });
      if (response.status === 200) {
        alert(response.data.message);
      } else {
        throw new Error("error accured");
      }
      const data = getUserData(limitGloble, pageGloble, isActiveGloble);
      dispatch({ type: ADD_USER, payload: data });
      return data;
    } catch (error) {
      dispatch(
        showMessage({
          message: error.response.data.message,
          variant: "error",
        })
      );
      return false;
    }
  };
};

export const updateUserData = (id, dataObj) => {
  return async (dispatch) => {
    try {
      const response = await axiosInstance({
        method: "put",
        url: `http://localhost:5007/update`,
        data: { id, dataObj },
      });
      const data = getUserData(limitGloble, pageGloble, isActiveGloble);
      alert("Successfully updated");
      dispatch({ type: UPDATE_USER, payload: data });
      return data;
    } catch (error) {
      dispatch(
        showMessage({
          message: error.response.data.message,
          variant: "error",
        })
      );
      return false;
    }
  };
};

export const softDeleteData = (id) => {
  return async (dispatch) => {
    console.log("softDeleteData");
    try {
      const response = await axiosInstance({
        method: "put",
        url: `http://localhost:5007/soft_delete/`,
        data: { id },
      });
      if (response.status === 200) {
        dispatch(
          showMessage({
            message: "Deleted successfully",
            variant: "success",
          })
        );
      } else {
        throw new Error("Deletion failed");
      }
      console.log(response);
      const data = getUserData(limitGloble, pageGloble, isActiveGloble);
      dispatch({ type: SOFT_DELETE_USER, payload: data });
    } catch (error) {
      dispatch(
        showMessage({
          message: error.response.data.message,
          variant: "error",
        })
      );
    }
  };
};

export const restoreData = (id) => {
  return async (dispatch) => {
    try {
      const response = await axiosInstance({
        method: "put",
        url: `http://localhost:5007/restore/`,
        data: { id },
      });
      if (response.status === 200) {
        dispatch(
          showMessage({
            message: "restored successfully",
            variant: "success",
          })
        );
      } else {
        throw new Error("Restoration failed");
      }
      console.log(response);
      const data = getUserData(limitGloble, pageGloble, isActiveGloble);
      dispatch({ type: SOFT_DELETE_USER, payload: data });
    } catch (error) {
      dispatch(
        showMessage({
          message: error.response.data.message,
          variant: "error",
        })
      );
    }
  };
};
