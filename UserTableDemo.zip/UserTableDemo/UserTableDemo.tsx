import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import DataTable from "./components/DataTable";
import FromModel from "./components/FormModel";
import {
  getUserData,
  GET_ALL_USERS,
} from "./store/actions/UserTableDemo.actions";
import { bindActionCreators } from "redux";
import UserTableDemoReducer from "./store/reducer/UserTableDemo.reducer";
import withReducer from "../../store/withReducer";
import Button from "@material-ui/core/Button";

function UserTableDemo(props) {
  const [usersArray, setUsersArray] = useState([]);
  const [userCount, setUsersCount] = useState(0);
  const [render, setRender] = useState(false);
  const [skip, setSkip] = useState(0);
  const [limit, setLimit] = useState(5);
  const [trash, setTrash] = useState(false);
  const [isActive, setIsActive] = useState(1);
  const { getUserData,user } = props;

  useEffect(() => {
    getUserData(limit, skip, isActive).then(({ data, dataCount }) => {
      setUsersCount(dataCount);
      setUsersArray(data);
    });
  }, [render]);

  function limitAndSkipHandler(limit, skip) {
    setSkip(skip);
    setLimit(limit);
    renderHandler();
  }

  function trashHandler() {
    setIsActive(-isActive);
    getUserData(limit, skip, isActive).then(({ data, dataCount }) => {
      setUsersCount(dataCount);
      setUsersArray(data);
    });
    setTrash(!trash);
    renderHandler();
  }

  function renderHandler() {
    setRender(!render);
  }

  return (
    <div className="container mx-auto px-4">
      <FromModel renderHandler={renderHandler}></FromModel>
      <Button variant="contained" onClick={trashHandler}>
        {trash ? "Go Back" : "Open Trash"}
      </Button>
      <DataTable
        trashHandler={trashHandler}
        trash={trash}
        userArray={usersArray}
        renderHandler={renderHandler}
        userCount={userCount}
        limitAndSkipHandler={limitAndSkipHandler}
      ></DataTable>
    </div>
  );
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators({ getUserData }, dispatch);
}

function mapStateToProps(state) {
  return {
    user: state.UserTableDemoReducer,
  };
}

export default withReducer(
  "UserTableDemoReducer",
  UserTableDemoReducer
)(connect(mapStateToProps, mapDispatchToProps)(UserTableDemo));
