import * as React from "react";
import { useState } from "react";
import Button from "@trenchaant/pkg-ui-component-library/build/Components/Button";
import TextField from "@trenchaant/pkg-ui-component-library/build/Components/TextField";
import Dialog from "@trenchaant/pkg-ui-component-library/build/Components/Dialog";
import DialogTitle from "@trenchaant/pkg-ui-component-library/build/Components/DialogTitle";
import EditIcon from "@material-ui/icons/Edit";
import axios from "axios";
import { updateUserData } from "../store/actions/UserTableDemo.actions";
import { connect } from "react-redux";
import storage from "./firebaseConfig";
import Avatar from "@trenchaant/pkg-ui-component-library/build/Components/Avatar";

interface dataObj {
  Profile?: String;
  Fname?: String;
  Lname?: String;
  Age?: String;
  Email?: String;
  PhoneNumber?: String;
  Pincode?: String;
  District?: String;
  State?: String;
  Country?: String;
}

function FormDialog({ updateUserData, row, renderHandler }) {
  const [open, setOpen] = useState(false);
  const [dataObj, setDataObj] = useState<dataObj>({});
  const [render, setRender] = useState(false);
  const [url, setUrl] = useState<String>("");

  const handleClickOpen = () => {
    renderHandlerLocal();
    setOpen(true);
  };

  const handleClose = () => {
    setDataObj({});
    renderHandler();
    setOpen(false);
  };

  const changeHandler = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    setDataObj({ ...dataObj, [name]: value });
  };

  const handleUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) {
      alert("Please upload an image first!");
    }
    const uploadTask = storage.ref(`/files/${file.name}`).put(file);
    uploadTask.on(
      "state_changed",
      (err) => {
        console.log("ERROR :", err);
      },
      () => {
        uploadTask.snapshot.ref.getDownloadURL().then((url) => {
          setUrl(url);
        });
      }
    );
  };

  const submitHandler = (e) => {
    e.preventDefault();
    updateUserData(row._id, dataObj);
    handleClose();
    renderHandler();
  };

  const pinCodedHandler = (value) => {
    setDataObj({ ...dataObj, Pincode: value });
    if (value?.length === 6) {
      axios
        .get(`https://api.postalpincode.in/pincode/${value}`)
        .then((response) => {
          return response.data;
        })
        .then((data) => {
          setDataObj({
            ...dataObj,
            District: data[0].PostOffice[0].District,
            State: data[0].PostOffice[0].State,
            Country: data[0].PostOffice[0].Country,
            Pincode: value,
          });
        });
    }
  };

  const renderHandlerLocal = () => {
    setRender(!render);
  };

  React.useEffect(() => {
    setUrl(row.Profile);
    const Profile = row.Profile;
    const Fname = row.Fname;
    const Lname = row.Lname;
    const Age = row.Age;
    const Email = row.Email;
    const PhoneNumber = row.PhoneNumber;
    const Pincode = row.Pincode;
    const District = row.District;
    const State = row.State;
    const Country = row.Country;
    pinCodedHandler(row.Pincode);
    setDataObj({
      Profile,
      Fname,
      Lname,
      Age,
      Email,
      PhoneNumber,
      Pincode,
      District,
      State,
      Country,
    });
  }, [row, render]);

  React.useEffect(() => {
    setDataObj({ ...dataObj, Profile: url });
  }, [url]);

  return (
    <div>
      <EditIcon onClick={handleClickOpen} />
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Update Form</DialogTitle>
        <form action="" onSubmit={submitHandler}>
          <div className="flex px-8">
            <Avatar alt="Remy Sharp" src={url} />
            <input
              name="Profile"
              id="outlined-basic"
              type="file"
              className="py-8"
              accept="image/png, image/jpg, image/gif, image/jpeg"
              onChange={(event) => handleUpload(event)}
            ></input>
          </div>
          <div className="flex px-8">
            <TextField
              id="outlined-basic"
              label="Fname"
              name="Fname"
              variant="outlined"
              required
              value={dataObj.Fname}
              onChange={changeHandler}
            />
          </div>
          <div className="flex px-8">
            <TextField
              id="outlined-basic"
              label="Lname"
              name="Lname"
              required
              variant="outlined"
              value={dataObj.Lname}
              onChange={changeHandler}
            />
          </div>
          <div className="flex px-8">
            <TextField
              id="outlined-basic"
              label="Age"
              name="Age"
              required
              variant="outlined"
              value={dataObj.Age}
              onChange={changeHandler}
            />
          </div>
          <div className="flex px-8">
            <TextField
              id="outlined-basic"
              label="Email"
              name="Email"
              type="email"
              required
              variant="outlined"
              value={dataObj.Email}
              onChange={changeHandler}
            />
          </div>
          <div className="flex px-8">
            <TextField
              id="outlined-basic"
              label="PhoneNumber"
              name="PhoneNumber"
              variant="outlined"
              required
              type="tel"
              value={dataObj.PhoneNumber}
              onChange={changeHandler}
            />
          </div>

          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
              padding: "10px",
            }}
          >
            <div className="p-8">
              <TextField
                type="text"
                variant="outlined"
                color="secondary"
                label="Zip Code"
                onChange={(e) => pinCodedHandler(e.target.value)}
                value={dataObj.Pincode ? dataObj.Pincode : ""}
                fullWidth
                required
              />
            </div>
            <div className="p-8">
              <TextField
                type="text"
                name="District"
                variant="outlined"
                color="secondary"
                label="District"
                onChange={changeHandler}
                value={dataObj.District ? dataObj.District : ""}
                fullWidth
                required
              />
            </div>
          </div>
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
              padding: "10px",
            }}
          >
            <div className="p-8">
              <TextField
                type="text"
                variant="outlined"
                color="secondary"
                label="state"
                name="State"
                onChange={changeHandler}
                value={dataObj.State ? dataObj.State : ""}
                fullWidth
                required
              />
            </div>
            <div className="p-8">
              <TextField
                type="text"
                variant="outlined"
                color="secondary"
                label="Country"
                name="Country"
                onChange={changeHandler}
                value={dataObj.Country ? dataObj.Country : ""}
                fullWidth
                required
              />
            </div>
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              width: "400px",
            }}
          ></div>

          <button
            type="submit"
            style={{
              padding: "10px",
              marginLeft: "10px",
              marginBottom: "10px",
            }}
            className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
          >
            Submit
          </button>
        </form>
      </Dialog>
    </div>
  );
}

function mapStateToProps(state) {
  return {
    user: state.UserTableDemoReducer,
  };
}

function mapDispatchToProps(dispatch) {
  return {
    updateUserData: (id, dataObj) => dispatch(updateUserData(id, dataObj)),
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(FormDialog);
