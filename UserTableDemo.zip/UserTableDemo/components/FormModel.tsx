import * as React from "react";
import { useState } from "react";
import Button from "@trenchaant/pkg-ui-component-library/build/Components/Button";
import TextField from "@trenchaant/pkg-ui-component-library/build/Components/TextField";
import Dialog from "@trenchaant/pkg-ui-component-library/build/Components/Dialog";
import DialogTitle from "@trenchaant/pkg-ui-component-library/build/Components/DialogTitle";
import axios from "axios";
import { addUserData } from "../store/actions/UserTableDemo.actions";
import { connect } from "react-redux";
import storage from "./firebaseConfig";
import Avatar from "@trenchaant/pkg-ui-component-library/build/Components/Avatar";

interface dataObj {
  Profile: String;
  Fname: String;
  Lname: String;
  Age: String;
  Email: String;
  PhoneNumber: String;
  Pincode: String;
  District?: String;
  State?: String;
  Country?: String;
}

function FormDialog({ addUserData, renderHandler, user }) {
  const [open, setOpen] = useState(false);
  const [dataObj, setDataObj] = useState<dataObj>({
    Profile: "",
    Fname: "",
    Lname: "",
    Age: "",
    Email: "",
    PhoneNumber: "",
    Pincode: "",
    District: "",
    State: "",
    Country: "",
  });
  const [url, setUrl] = useState<String>("");
  const [percent, setPercent] = useState(0);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setUrl("");
    setDataObj({
      Profile: "",
      Fname: "",
      Lname: "",
      Age: "",
      Email: "",
      PhoneNumber: "",
      Pincode: "",
      District: "",
      State: "",
      Country: "",
    });
    setOpen(false);
  };

  const changeHandler = (event) => {
    const name = event.target.name;
    const value = event.target.value.trim();
    setDataObj({ ...dataObj, [name]: value });
    console.log(dataObj);
  };

  const handleUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) {
      alert("Please upload an image first!");
    }
    const uploadTask = storage.ref(`/files/${file.name}`).put(file);

    uploadTask.on(
      "state_changed",
      (snapshot) => {
        console.log(percent);
      },
      (err) => {
        console.log("ERROR :", err);
      },
      () => {
        uploadTask.snapshot.ref.getDownloadURL().then((url) => {
          setUrl(url);
          console.log("AVATAR URL : ------------->", url);
        });
      }
    );
  };

  const pinCodedHandler = (value) => {
    setDataObj({ ...dataObj, Pincode: value });
    if (value.length === 6) {
      axios
        .get(`https://api.postalpincode.in/pincode/${value}`)
        .then((response) => {
          return response.data;
        })
        .then((data) => {
          const po = data[0]?.PostOfficeCode[0];
          setDataObj({
            ...dataObj,
            District: po.District,
            State: po.State,
            Country: po.Country,
            Pincode: value,
          });
        })
        .catch((err) => {
          alert("Something went wrong at POSTCODEAPI");
          console.log(err);
        });
    } else if (value.length > 6) {
      alert("enter valid pincode");
    }
  };

  const submitHandler = (event) => {
    event.preventDefault();
    renderHandler();
    addUserData(dataObj);
    handleClose();
  };

  React.useEffect(() => {
    setDataObj({ ...dataObj, Profile: url });
  }, [url]);

  return (
    <div style={{ padding: "20px", paddingLeft: "0px" }}>
      <Button variant="outlined" onClick={handleClickOpen}>
        Open form dialog
      </Button>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>User Form</DialogTitle>
        <form action="" onSubmit={submitHandler}>
          <div className="container mx-auto px-6 my-auto py-6 my-8">
            <div className="flex px-8">
              <Avatar alt="Remy Sharp" src={url} />
              <input
                name="Profile"
                id="outlined-basic"
                type="file"
                className="py-8"
                accept="image/png, image/jpg, image/gif, image/jpeg"
                onChange={(event) => handleUpload(event)}
              ></input>
            </div>

            <div className="p-8">
              <TextField
                id="outlined-basic"
                label="Fname"
                name="Fname"
                variant="outlined"
                required
                type={String}
                onChange={changeHandler}
              />
              <TextField
                id="outlined-basic"
                required
                label="Lname"
                name="Lname"
                variant="outlined"
                type={String}
                onChange={changeHandler}
              />
              <TextField
                id="outlined-basic"
                label="Age"
                name="Age"
                variant="outlined"
                required
                type={Number}
                onChange={changeHandler}
              />
              <TextField
                id="outlined-basic"
                label="Email"
                name="Email"
                type="email"
                variant="outlined"
                required
                onChange={changeHandler}
              />
              <TextField
                id="outlined-basic"
                label="PhoneNumber"
                name="PhoneNumber"
                variant="outlined"
                type="tel"
                required
                onChange={changeHandler}
              />
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                  padding: "10px",
                }}
              >
                <TextField
                  type="text"
                  variant="outlined"
                  color="secondary"
                  label="Zip Code"
                  onChange={(e) => pinCodedHandler(e.target.value)}
                  fullWidth
                  required
                />
                <TextField
                  type="text"
                  name="District"
                  variant="outlined"
                  color="secondary"
                  label="District"
                  onChange={changeHandler}
                  value={dataObj.District ? dataObj.District : ""}
                  fullWidth
                  required
                />
              </div>
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                  padding: "10px",
                }}
              >
                <TextField
                  type="text"
                  variant="outlined"
                  color="secondary"
                  label="state"
                  name="State"
                  onChange={changeHandler}
                  value={dataObj.State ? dataObj.State : ""}
                  fullWidth
                  required
                />
                <TextField
                  type="text"
                  variant="outlined"
                  color="secondary"
                  label="Country"
                  name="Country"
                  onChange={changeHandler}
                  value={dataObj.Country ? dataObj.Country : ""}
                  fullWidth
                  required
                />
              </div>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                width: "400px",
              }}
            ></div>
            <button
              type="submit"
              style={{
                padding: "10px",
                marginLeft: "10px",
                marginBottom: "10px",
              }}
              className="bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded"
            >
              Submit
            </button>
          </div>
        </form>
      </Dialog>
    </div>
  );
}

function mapStateToProps(state) {
  return {
    user: state.UserTableDemoReducer,
  };
}

function mapDispatchToProps(dispatch) {
  return {
    addUserData: (dataObj) => dispatch(addUserData(dataObj)),
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(FormDialog);
