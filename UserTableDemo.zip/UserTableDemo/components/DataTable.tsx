import * as React from "react";
import { DeleteForever } from "@material-ui/icons";
import EditIcon from "@material-ui/icons/Edit";
import Paper from "@trenchaant/pkg-ui-component-library/build/Components/Paper";
import Table from "@trenchaant/pkg-ui-component-library/build/Components/Table";
import TableBody from "@trenchaant/pkg-ui-component-library/build/Components/TableBody";
import TableCell from "@trenchaant/pkg-ui-component-library/build/Components/TableCell";
import TableContainer from "@trenchaant/pkg-ui-component-library/build/Components/TableContainer";
import TableHead from "@trenchaant/pkg-ui-component-library/build/Components/TableHead";
import TablePagination from "@trenchaant/pkg-ui-component-library/build/Components/TablePagination";
import TableRow from "@trenchaant/pkg-ui-component-library/build/Components/TableRow";
import RestoreIcon from "@material-ui/icons/Restore";

import {
  deleteUserData,
  restoreData,
  softDeleteData,
} from "../store/actions/UserTableDemo.actions";

import { connect, useDispatch } from "react-redux";
import DeleteOutlinedIcon from "@material-ui/icons/DeleteOutlined";
import Avatar from "@trenchaant/pkg-ui-component-library/build/Components/Avatar";
import FormModelUpdate from "./FormModelUpdate";
import {boolean} from "yup";
import { Object } from "lodash";

interface Column {
  id: "Fname" | "Lname" | "Email" | "PhoneNumber" | "Age" | "Profile";
  label: string;
  minWidth?: number;
  align?: "left";
  format?: (value: number) => string;
}

interface props{
  userArray:Array<any>;
  userCount:Number;
  deleteUserData : Function;
  renderHandler : Function;
  limitAndSkipHandler : Function ;
  softDeleteData : Function ;
  trashHandler: Function;
  trash : boolean;
  restoreData : Function;
}

interface id {
  id ?: String;
}

const columns: readonly Column[] = [
  {
    id: "Fname",
    label: "First Name",
    minWidth: 170,
    align: "left",
  },
  {
    id: "Lname",
    label: "Last Name",
    minWidth: 170,
    align: "left",
  },
  {
    id: "Email",
    label: "Email",
    minWidth: 170,
    align: "left",
  },
  {
    id: "PhoneNumber",
    label: "PhoneNumber",
    minWidth: 170,
    align: "left",
  },
  {
    id: "Age",
    label: "Age",
    minWidth: 170,
    align: "left",
  },
];

function DataTable({
  userArray,
  userCount,
  deleteUserData,
  renderHandler,
  limitAndSkipHandler,
  softDeleteData,
  trashHandler,
  trash,
  restoreData,
} : props) {
  const [page, setPage] = React.useState(0);
  const [rows, setRows] = React.useState<Array<any>>([]);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const handleChangePage = (event: unknown, newPage: number) => {
    limitAndSkipHandler(rowsPerPage, newPage);
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
    limitAndSkipHandler(+event.target.value, 0);
  };

  React.useEffect(() => {
    setRows(userArray);
  });

  function deleteHandler(id : id) {
    deleteUserData(id);
    renderHandler();
  }

  function softDeleteHandler(id : id) {
    softDeleteData(id);
    renderHandler();
  }

  function restoreHandler(id : id) {
    restoreData(id);
    trashHandler();
    renderHandler();
  }

  return (
    <Paper sx={{ width: "50%", overflow: "hidden" }}>
      <TableContainer sx={{ maxHeight: 50 }}>
        <Table
          tablePagination={{
            rowsPerPageOptions: [5, 10, 15],
            component: "div",
            count: userCount,
            rowsPerPage,
            page,
            onChangePage: handleChangePage,
            onChangeRowsPerPage: handleChangeRowsPerPage,
          }}
          totalRecords={userCount}
          totalLabel={"record"}
          stickyHeader
          aria-label="sticky table"
        >
          <TableHead>
            <TableRow>
              <TableCell>Profile</TableCell>
              {columns.map((column) => (
                <TableCell
                  key={column.id}
                  align={column.align}
                  style={{ minWidth: column.minWidth }}
                >
                  {column.label}
                </TableCell>
              ))}
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row: { Profile : String; _id : id; isActive : Number }) => {
              return (
                <>
                  {row.isActive && (
                    <TableRow hover role="checkbox" tabIndex={-1} key={row._id}>
                      <TableCell>
                        <Avatar src={row.Profile}></Avatar>
                      </TableCell>
                      {columns.map((column) => {
                        const value = row[column.id];
                        return (
                          <TableCell key={column.id} align={column.align}>
                            {column.format && typeof value === "number"
                              ? column.format(value)
                              : value}
                          </TableCell>
                        );
                      })}
                      <TableCell>
                        {!trash ? (
                          <div
                            style={{ display: "flex", flexDirection: "row" }}
                          >
                            <DeleteOutlinedIcon
                              onClick={() => {
                                softDeleteHandler(row._id);
                              }}
                            ></DeleteOutlinedIcon>
                            <FormModelUpdate
                              row={row}
                              renderHandler={renderHandler}
                            ></FormModelUpdate>
                          </div>
                        ) : (
                          <>
                            <RestoreIcon
                              onClick={() => restoreHandler(row._id)}
                            />
                            <DeleteForever
                              onClick={() => {
                                deleteHandler(row._id);
                              }}
                            ></DeleteForever>
                          </>
                        )}
                      </TableCell>
                    </TableRow>
                  )}
                </>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
}

interface state {
  UserTableDemoReducer : ObjectConstructor
}
function mapStateToProps(state : state) {
  return {
    user: state.UserTableDemoReducer,
  };
}
function mapDispatchToProps(dispatch : Function) {
  return {
    deleteUserData: (id : id) => dispatch(deleteUserData(id)),
    softDeleteData: (id : id) => dispatch(softDeleteData(id)),
    restoreData: (id : id) => dispatch(restoreData(id)),
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(DataTable);
